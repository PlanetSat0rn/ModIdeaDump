/*
 *	MCreator note:
 *
 *	If you lock base mod element files, you can edit this file and the proxy files
 *	and they won't get overwritten. If you change your mod package or modid, you
 *	need to apply these changes to this file MANUALLY.
 *
 *
 *	If you do not lock base mod element files in Workspace settings, this file
 *	will be REGENERATED on each build.
 *
 */
package net.mcreator.saturnschaoticmod;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

import net.mcreator.saturnschaoticmod.network.SaturnsChaoticModModVariables;
import net.mcreator.saturnschaoticmod.init.SaturnsChaoticModModTabs;
import net.mcreator.saturnschaoticmod.init.SaturnsChaoticModModSounds;
import net.mcreator.saturnschaoticmod.init.SaturnsChaoticModModProcedures;
import net.mcreator.saturnschaoticmod.init.SaturnsChaoticModModItems;
import net.mcreator.saturnschaoticmod.init.SaturnsChaoticModModEntities;

import net.fabricmc.api.ModInitializer;

public class SaturnsChaoticModMod implements ModInitializer {
	public static final Logger LOGGER = LogManager.getLogger();
	public static final String MODID = "saturns_chaotic_mod";

	@Override
	public void onInitialize() {
		LOGGER.info("Initializing SaturnsChaoticModMod");
		SaturnsChaoticModModTabs.load();

		SaturnsChaoticModModEntities.load();

		SaturnsChaoticModModItems.load();

		SaturnsChaoticModModProcedures.load();

		SaturnsChaoticModModSounds.load();
		SaturnsChaoticModModVariables.SyncJoin();
		SaturnsChaoticModModVariables.SyncChangeWorld();
	}
}
