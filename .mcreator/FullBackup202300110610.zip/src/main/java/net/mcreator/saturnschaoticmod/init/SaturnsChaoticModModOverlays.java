/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.saturnschaoticmod.init;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.api.Environment;
import net.fabricmc.api.EnvType;

@Environment(EnvType.CLIENT)
public class SaturnsChaoticModModOverlays {
	public static void load() {
		HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
			PanicOverlay.render(matrices, tickDelta);
		});
	}
}
