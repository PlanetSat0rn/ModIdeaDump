package net.mcreator.saturnschaoticmod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.saturnschaoticmod.network.SaturnsChaoticModModVariables;
import net.mcreator.saturnschaoticmod.SaturnsChaoticModMod;

import java.util.Map;

public class PanicDisplayOverlayIngameProcedure {

	public static boolean execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				SaturnsChaoticModMod.LOGGER.warn("Failed to load dependency world for procedure PanicDisplayOverlayIngame!");
			return false;
		}
		LevelAccessor world = (LevelAccessor) dependencies.get("world");
		boolean paniccheck = false;
		if (SaturnsChaoticModModVariables.MapVariables.get(world).panic == 1) {
			paniccheck = true;
		} else {
			paniccheck = false;
		}
		return paniccheck;
	}
}
