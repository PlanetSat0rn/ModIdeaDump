package net.mcreator.saturnschaoticmod.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.saturnschaoticmod.network.SaturnsChaoticModModVariables;
import net.mcreator.saturnschaoticmod.SaturnsChaoticModMod;

import java.util.Map;

public class TimerCounterProcedure {

	public static double execute(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				SaturnsChaoticModMod.LOGGER.warn("Failed to load dependency world for procedure TimerCounter!");
			return 0;
		}
		LevelAccessor world = (LevelAccessor) dependencies.get("world");
		return SaturnsChaoticModModVariables.WorldVariables.get(world).timer;
	}
}
