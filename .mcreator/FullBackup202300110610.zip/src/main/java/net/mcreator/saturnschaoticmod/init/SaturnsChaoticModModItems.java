
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.saturnschaoticmod.init;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.Registry;

import net.mcreator.saturnschaoticmod.item.ShotgunItem;
import net.mcreator.saturnschaoticmod.item.BulletItem;
import net.mcreator.saturnschaoticmod.SaturnsChaoticModMod;

public class SaturnsChaoticModModItems {
	public static Item SHOTGUN;
	public static Item BULLET;

	public static void load() {
		SHOTGUN = Registry.register(Registry.ITEM, new ResourceLocation(SaturnsChaoticModMod.MODID, "shotgun"), new ShotgunItem());
		BULLET = Registry.register(Registry.ITEM, new ResourceLocation(SaturnsChaoticModMod.MODID, "bullet"), new BulletItem());
	}
}
