
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.saturnschaoticmod.init;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.resources.ResourceLocation;

import net.fabricmc.fabric.api.client.itemgroup.FabricItemGroupBuilder;

public class SaturnsChaoticModModTabs {
	public static CreativeModeTab TAB_WAR;

	public static void load() {
		TAB_WAR = FabricItemGroupBuilder.create(new ResourceLocation("saturns_chaotic_mod", "war")).icon(() -> new ItemStack(SaturnsChaoticModModItems.SHOTGUN)).build();
	}
}
