
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.saturnschaoticmod.init;

import net.mcreator.saturnschaoticmod.procedures.TimerCounterProcedure;
import net.mcreator.saturnschaoticmod.procedures.PanicValueProcedure;
import net.mcreator.saturnschaoticmod.procedures.PanicDisplayOverlayIngameProcedure;

@SuppressWarnings("InstantiationOfUtilityClass")
public class SaturnsChaoticModModProcedures {
	public static void load() {
		new TimerCounterProcedure();
		new PanicDisplayOverlayIngameProcedure();
		new PanicValueProcedure();
	}
}
